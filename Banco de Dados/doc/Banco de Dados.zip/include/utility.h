#ifndef _UTILITY_H_
#define _UTILITY_H_

int numberSort(const void *, const void *);
int binarySearch(Idx_File *, const int, const int, int *);
char *readline(FILE *);

#endif